<?php

$firstname = $_POST["firstname"];
$lastname = $_POST["lastname"];
$username = $_POST["username"];
$password = $_POST["password"];
$isAdmin = $_POST["isAdmin"];

include('includes/db-config.php');

$sql = "INSERT INTO `person`(firstname, lastname, username, password, isAdmin)
  	VALUES ('$firstname', '$lastname', '$username', '$password', '$isAdmin');";

if ($conn->query($sql) === TRUE) {

  // get last id
  $personId = $conn->insert_id;
  $sql2 = "SELECT * FROM person WHERE personId=$personId";
  $result2 = $conn->query($sql2);
  $person = $result2->fetch_assoc();

  // initiate session for logged in user
  session_start();
  $_SESSION["person"] = $person;

  echo "Thank you";
  ?>
  <br><br>
  <a href="index.php">Home</a>
  <?php
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();

?>
