<?php

include("session.php");

if (!$person) {
  header("Location: login.php");
}

include('header.php');
include('cms-header.php');

?>

<a href="add_article.php">Add Article</a>
<hr>

<?php

include("includes/db-config.php");
$sql = "SELECT * FROM articles";
$result = $conn->query($sql);

?>

<table>
  <tr>
    <th>#</th>
    <th>Title</th>
    <th>Author</th>
    <th>Actions</th>
  </tr>

  <?php
  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      ?>
      <tr>
        <td>
          <?php echo $row['id']; ?>
        </td>
        <td>
          <?php echo $row['title']; ?>
        </td>
        <td>
          <?php echo $row['author']; ?>
        </td>
        <td>
          <a href="edit_article.php?id=<?php echo $row['id']; ?>">Edit</a>
          <a href="delete_article.php?id=<?php echo $row['id']; ?>">Delete</a>
          <?php
          if ($row['isFeatured']) {
            ?>
              <a href="feature_article.php?id=<?php echo $row['id']; ?>&feature=0">Unfeature</a>
            <?php
          } else {
            ?>
            <a href="feature_article.php?id=<?php echo $row['id']; ?>&feature=1">Feature</a>
            <?php
          }
          ?>
        </td>
      </tr>
      <?php
    }
  }
  ?>

</table>

<?php

include('footer.php');

?>
