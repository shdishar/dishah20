<?php

// get logged in user details
session_start();

// if not logged in, redirect to login
if (!isset($_SESSION['person'])) {
  header("Location: login.php");
}

// user is logged in, process article
// read inputs
$id = $_POST['id'];
$category = $_POST["category"];
$title = $_POST["title"];
$author = $_POST["author"];
$article = $_POST["article"];
$currentImage = $_POST["currentImage"];
$external_link = $_POST["externalLink"];

// upload image
$uploadedImage = $currentImage;

if ($_FILES["image"]["name"]) {
	$target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["image"]["name"]);
	move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
	$uploadedImage = $target_file;
}

// connect db
include('includes/db-config.php');

// insert data
$sql = 'UPDATE articles
SET category="' . $category . '", title="' . $title . '", author="' . $author . '", article="' . $article . '", image="' . $uploadedImage . '", external_link="' . $external_link . '"
WHERE id=' . $id;


$result = $conn->query($sql);
$conn->close();

// sql error, die
if (!$result) {
  die("Error: " . $sql . "<br>" . $conn->error);
}

// redirect to all articles page if successful
header("Location: cms-articles.php");

?>
