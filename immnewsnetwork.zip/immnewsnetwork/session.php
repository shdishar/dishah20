<?php

session_start();

$person = false;
if (isset($_SESSION['person'])) {
  $person = $_SESSION['person'];
}

?>
