<?php

include("session.php");
include("header.php");
include("includes/db-config.php");

?>
    <main>
      <section>
        <h1>Welcome to the IMM News Network!</h1>
        <p> IMM News Network is an initiative by graduates from Sheridan's Interactive Media Manangement (IMM) students.
          We invite all the interactive media experts to share their knowledge on the latest technologies and development,
          careers in Interactive Media and the current state of industry. Register to become a writer or contributor of the IMM News Network today!
        </p>
      </section>

      <section>
        <h1>Featured article of the month</h1>
        <?php
        $sql = "SELECT * FROM articles WHERE isFeatured=1 LIMIT 1";
        $result = $conn->query($sql);
        ?>
        <table>
          <?php
          if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
              ?>
              <tr>
                <td>
                  <h2><?php echo $row['title']; ?></h2>
                  <small><?php echo $row['author']; ?></small><br><br>
                    <img src="<?php echo $row['image']; ?>" height="200" />
                  <p><?php
                  $ps = explode("\r\n", $row['article']);
                  $p = trim($ps[0]);
                  echo $p;
                  ?></p>
                  <a href="article.php?id=<?php echo $row['id']; ?>">Read More</a>
                </td>
              </tr>
              <?php
            }
          }
          ?>
        </table>
      </section>

      <section>
        <hr>
        <h1>Category Interests</h1>
        <?php
        $sql1 = "SELECT * FROM catIn";
        $result1 = $conn->query($sql1);

        if ($result1->num_rows > 0) {
          // output data of each row
          while($row1 = $result1->fetch_assoc()) {
            ?>

            <h2><?php echo $row1['catInName']; ?></h2>
            <table>
              <?php

              $sql2 = "SELECT * FROM articles WHERE category={$row1['catInId']} LIMIT 2";
              $result2 = $conn->query($sql2);

              if ($result2->num_rows > 0) {
                // output data of each row
                while($row2 = $result2->fetch_assoc()) {
                  ?>

                  <tr>
                    <td>

                      <h2><?php echo $row2['title']; ?></h2>
                      <small><?php echo $row2['author']; ?></small><br><br>
                      <img src="<?php echo $row2['image']; ?>" height="200" />
                      <p><?php
                      $ps = explode("\r\n", $row2['article']);
                      $p = trim($ps[0]);
                      echo $p;
                      ?></p>
                      <a href="article.php?id=<?php echo $row2['id']; ?>">Read More</a>
                      <hr>
                    </td>
                  </tr>

                  <?php
                }
              }

              ?>
            </table>
            <hr>
            <?php

          }
        }

        ?>
      </section>




<h1>Visitors</h1>
    <table>
      <tr>
        <th>Month</th>
        <th>Number of Visitors</th>
      </tr>

      <?php

      $sql = "SELECT count(*) as visits, month(time) as month FROM `visitor` GROUP BY month(time) LIMIT 6";
      $result = $conn->query($sql);

      while ($row = $result->fetch_assoc()) {
        ?>
        <tr>
          <td><?php echo $row['month']; ?></td>
          <td><?php echo $row['visits']; ?></td>
        </tr>
        <?php
      }
      ?>
</table>
<br><br>

<iframe width="560" height="315" src="https://www.youtube.com/embed/PcY9_mCT2D8" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<?php

include('footer.php');

?>
