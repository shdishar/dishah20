<?php

// read inputs
$username = $_POST["username"];
$password = $_POST["password"];

// connect db
include('includes/db-config.php');

//check the username and password against the database records
$sql = "SELECT * FROM `person`
	WHERE `username` = '$username'
	AND `password` = '$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
		$row = $result->fetch_assoc();
		$conn->close();

		// initiate session for logged in user
		session_start();
		$_SESSION["person"] = $row;

		// echo '<p>firstname:'. $row['firstname'] . '</p>';
		// echo '<p>lastname:'. $row['lastname'] . '</p>';
		// echo '<p>isAdmin:'. $row['isAdmin'] . '</p>';

		// check if isAdmin:
		// admin -> cms.php
		// member -> index.php
		if ($row['isAdmin']) {
			header("Location: cms-articles.php");
		} else {
			header("Location: index.php");
		}
} else {
	header("Location: login.php");
}

?>
