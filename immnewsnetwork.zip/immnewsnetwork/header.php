<!DOCTYPE HTML>
<html>
  <head>
      <meta charset="utf-8">
      <title>IMM News Network</title>
      <link rel="icon" href="http://localhost:8888/immnewsnetwork/favicon.png">
    </head>
  <body>

  <header>
    <img src="images/logo.png" width="400"/>
    <br>
    <a href="index.php">[Home]</a>
    <a href="about.php">[About]</a>
    <a href="contact.php">[Contact]</a>

    <?php

    if ($person) {
      if ($person['isAdmin']) {
        ?>
        <a href="cms-articles.php">[CMS]</a>
        <?php
      }
      ?>
      <a href="logout.php">[Logout]</a>
      <?php
    } else {
      ?>
        <a href="login.php">[Login]</a>
        <a href="register.php">[Register]</a>
      <?php
    }

    ?>
    <hr>
  </header>
