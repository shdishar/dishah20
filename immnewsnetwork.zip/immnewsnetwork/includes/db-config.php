<?php
$servername = "localhost";
$dbusername = "shdishar_shdishar";
$dbpassword = "shdishar_shdishar";
$dbname = "shdishar_immnewsnetwork";

// Create connection
$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";

$sql = "INSERT INTO visitor (time) VALUES (CURRENT_TIMESTAMP)";
$conn->query($sql);

?>
