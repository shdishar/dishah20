<?php

$articleId = $_GET['id'];
$feature = $_GET['feature'];

include("includes/db-config.php");
$sql = "UPDATE articles SET isFeatured=$feature WHERE id=$articleId";
$result = $conn->query($sql);
$conn->close();

if ($result) {
  header("Location: cms-articles.php");
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

?>
