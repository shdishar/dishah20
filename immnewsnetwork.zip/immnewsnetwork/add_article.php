<?php

include("session.php");

// if not logged in, redirect to login
if (!$person) {
  header("Location: login.php");
}

// if logged in but not admin, redirect to login
$isAdmin = $person['isAdmin'];
if (!$isAdmin) {
    header("Location: login.php");
}

//allowed to see this page
?><!DOCTYPE html>
<html>
<head>
</head>
<body>
<form action="process_add_article.php" method="POST" enctype="multipart/form-data">
  <?php

  // connect db
  include('includes/db-config.php');

  ?>

	<label>category</label><br>
  <select name="category">
  <?php

  // show list of article categories to choose from

  $sql = "SELECT * FROM catIn";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      echo '<option value="' . $row['catInId'] . '">' . $row['catInName'] . '</option>';
    }
  }

  ?>
  </select>

  <br><br>

	<label>title</label><br>
  <input type="text" name="title" />

  <br><br>

	<label>author</label><br>
  <input type="text" name="author" />

  <br><br>

  <label>content</label><br>
  <textarea name="article"></textarea>

  <br><br>

  <label>image</label><br>
  <input type="file" name="image" />

  <br><br>

  <label>external link</label><br>
  <input type="text" name="externalLink" />

  <br><br>

	<input type="submit" />
</form>


<?php

include('footer.php');

?>
