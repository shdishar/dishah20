<?php

include("session.php");
include("header.php");
include("includes/db-config.php");

?>


<form action="contactform.php" method="POST">
  <h1>Contact</h1>
  <hr>
  <h3>Personal Information</h3>
    <label for="fName">First Name:</label><br>
    <br>

    <input type="text" name="fName" placeholder="Enter First Name" id="fName"/><br>
    <br>
    <br>

    <label for="lName">Last Name:</label><br>
    <br>
    <input type="text" name="lName" placeholder="Enter Last Name" id="lName"/><br>
    <br>
    <br>

    <label for="emailAddress">Email Address:</label><br>
    <br>
    <input type="text" name="emailAddress" placeholder="eg:abc@gmail.com" id="emailAddress"/><br>
    <br>
    <hr>
    <h3>Category Interests</h3>
    <small>You can select more than one options.</small><br>
    <br>

  <?php


$sql = "SELECT catInId, catInName FROM catIn";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo '<input type="checkbox" name="catInId[]" id="catInId' . $row['catInId'] . '" value="' . $row['catInId'] . '" />
    <label for="catInId' . $row['catInId'] . '">' . $row['catInName'] . '</label><br><br>';
  }
}

?>

    <hr>
    <h3>Your Role</h3>
    <select name="roleId">

      <?php

      $sql = "SELECT roleId, roleName FROM role";
      $result = $conn->query($sql);

      if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
          echo '<option value="' . $row['roleId'] . '">' . $row['roleName'] . '</option>';
        }
      }
      $conn->close();
      ?>
    </select>
<br><br>
<input type="submit" />




  </form>
  <?php

  include('footer.php');

  ?>
