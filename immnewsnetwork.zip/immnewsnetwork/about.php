<?php

include("session.php");


// connect db
include("includes/db-config.php");

include('header.php');
include('cms-header.php');

?>

	<?php

  // show list of article categories to choose from

  $sql = "SELECT content FROM about";
  $result = $conn->query($sql);

  // output data of each row
  $row = $result->fetch_assoc();
  $content = $row['content'];
  $content = str_replace("\n", "<br>", $content);

  ?>
  <h1>About</h1>
  <p><?php echo $content; ?></p>



<?php
include('footer.php');
?>
