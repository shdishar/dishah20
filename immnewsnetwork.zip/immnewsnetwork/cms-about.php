<?php

include("session.php");

// if not logged in, redirect to login
if (!$person) {
  header("Location: login.php");
}

// if logged in but not admin, redirect to login
$isAdmin = $person['isAdmin'];
if (!$isAdmin) {
    header("Location: login.php");
}

// connect db
include("includes/db-config.php");

include('header.php');
include('cms-header.php');

?>

<form method="POST">
	<?php

  // update content sql
  if ($_POST['content']) {
    $sql = 'UPDATE about SET content="' . $_POST['content'] . '"';
    $result = $conn->query($sql);
    if (!$result) {
      echo "<p>Error updating content</p>";
    } else {
      echo "<p>Content updated</p>";
    }
  }

  // show list of article categories to choose from

  $sql = "SELECT content FROM about";
  $result = $conn->query($sql);

  // output data of each row
  $row = $result->fetch_assoc();

  ?>
  <label>content</label><br>
  <textarea name="content"><?php echo $row['content']; ?></textarea>
  <br><br>
  <input type="submit" />
</form>

<?php
include('footer.php');
?>
