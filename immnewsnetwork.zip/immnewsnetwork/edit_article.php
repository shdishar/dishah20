<?php

include("session.php");

// if not logged in, redirect to login
if (!$person) {
  header("Location: login.php");
}

// if logged in but not admin, redirect to login
$isAdmin = $person['isAdmin'];
if (!$isAdmin) {
    header("Location: login.php");
}

$articleId = $_GET['id'];

include('includes/db-config.php');
$sql = "SELECT * FROM articles WHERE id=$articleId";
$result = $conn->query($sql);

$form = $result->fetch_assoc();

//allowed to see this page
?><!DOCTYPE html>
<html>
<head>
</head>
<body>
<form action="process_edit_article.php" method="POST" enctype="multipart/form-data">
	<label>category</label><br>
  <select name="category">
  <?php

  // show list of article categories to choose from

  $sql = "SELECT * FROM catIn";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
			$selected = ($row['catInId'] == $form['category']) ? 'selected' : '';
      echo '<option value="' . $row['catInId'] . '" ' . $selected . '>' . $row['catInName'] . '</option>';
    }
  }

  ?>
  </select>

  <br><br>

	<label>title</label><br>
  <input type="text" name="title" value="<?php echo $form['title']; ?>" />

  <br><br>

	<label>author</label><br>
  <input type="text" name="author" value="<?php echo $form['author']; ?>" />

  <br><br>

  <label>content</label><br>
  <textarea name="article"><?php echo $form['article']; ?></textarea>

  <br><br>

  <label>image</label><br>
  <input type="file" name="image" />

  <br><br>

  <label>external link</label><br>
  <input type="text" name="externalLink" value="<?php echo $form['external_link']; ?>" />

  <br><br>

	<input type="hidden" name="currentImage" value="<?php echo $form['image']; ?>" />
	<input type="hidden" name="id" value="<?php echo $articleId; ?>" />

	<input type="submit" />
</form>
<?php

include('footer.php');

?>
