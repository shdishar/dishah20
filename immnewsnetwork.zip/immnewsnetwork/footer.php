<footer>
  <h3>THIS WEBSITE USES COOKIES</h3>
  <p>We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our site with our social media, advertising and analytics partners who may combine it with other information that you’ve provided to them or that they’ve collected from your use of their services. You consent to our cookies if you continue to use our website.</p>
  <p><a href="#">[OK]</a> <a href="#">[Decline]</a></p>
</footer>
</body>
</html>
