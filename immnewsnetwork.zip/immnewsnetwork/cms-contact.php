<?php

include("session.php");

if (!$person) {
  header("Location: login.php");
}

include('header.php');
include('cms-header.php');

?>


<?php

include("includes/db-config.php");
$sql = "SELECT * FROM user";
$result = $conn->query($sql);

?>

<table>
  <tr>
    <th>#</th>
    <th>fName</th>
    <th>lName</th>
    <th>emailAddress</th>
    <th>roleId</th>
  </tr>

  <?php
  if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
      ?>
      <tr>
        <td>
          <?php echo $row['#']; ?>
        </td>
        <td>
          <?php echo $row['fName']; ?>
        </td>
        <td>
          <?php echo $row['lName']; ?>
        </td>
        <td>
          <?php echo $row['emailAddress']; ?>
        </td>
        <td>
          <?php echo $row['roleId']; ?>
        </td>
        
      </tr>
      <?php
    }
  }
  ?>

</table>

<?php

include('footer.php');

?>
