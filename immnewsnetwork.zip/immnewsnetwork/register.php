<!DOCTYPE HTML>
<html>
  <head>
      <meta charset="utf-8">
      <title>IMM News Network</title>
    </head>
  <body>
	<form action="process-register.php" method="POST">
		firstname: <input type="text" name="firstname" /><br><br>
		lastname: <input type="text" name="lastname" /><br><br>
		username: <input type="text" name="username" /><br><br>
		password: <input type="text" name="password" /><br><br>

		<input type="radio" id="Admin" name="isAdmin" value="1">
		<label for="Admin">Admin</label>

		<input type="radio" id="Member" name="isAdmin" value="0">
  	<label for="Member">Member</label>

		<br><br>

		<input type="submit" />
	
	</form>
</body>
</html>
