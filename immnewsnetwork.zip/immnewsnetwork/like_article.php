<?php

include("session.php");

if (!$person) {
  header("Location: login.php");
}

$userId = $person['personId'];
$articleId = $_GET['articleId'];

include("includes/db-config.php");
$sql = 'INSERT INTO `user-likes` (userId, articleId)
VALUES (' . $userId . ', ' . $articleId . ')';
$result = $conn->query($sql);
$conn->close();

if ($result) {
  header('Location: article.php?id=' . $articleId);
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

?>
