<?php

$id = $_GET["id"];

include('includes/db-config.php');

$sql = "DELETE FROM articles WHERE id=$id";
$result = $conn->query($sql);
$conn->close();

if ($result) {
  header("Location: cms-articles.php");
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

?>
