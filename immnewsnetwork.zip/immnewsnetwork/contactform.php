<?php

$fName = $_POST["fName"];
$lName = $_POST["lName"];
$emailAddress = $_POST["emailAddress"];
$catInIds = $_POST["catInId"];
$roleId = $_POST["roleId"];


include('includes/db-config.php');



$sql = "INSERT INTO user (fName, lName, emailAddress, roleId)
VALUES ('$fName', '$lName', '$emailAddress', '$roleId')";
if ($conn->query($sql) === TRUE) {
	$userId = $conn->insert_id;
  //echo "New record created successfully. Last inserted ID is: " . $userId;
} else {
die("Error: " . $sql . "<br>" . $conn->error);
}


foreach ($catInIds as $catInId) {
	$sql = "INSERT INTO `user-catIn` (userId, catInId)
	VALUES ('$userId', '$catInId')";
	if ($conn->query($sql) === TRUE) {
  //echo "New record created successfully.";
} else {
die("Error: " . $sql . "<br>" . $conn->error);
}
}
echo "thank you";
$conn->close();

?>
