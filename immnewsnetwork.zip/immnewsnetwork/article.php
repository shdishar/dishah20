<?php

include("session.php");
include("header.php");
include("includes/db-config.php");

$articleId = $_GET['id'];

$sql = "SELECT * FROM articles WHERE id=$articleId";
$result = $conn->query($sql);

$row = $result->fetch_assoc();

?>

<?php

if ($person) {
  $userId = $person['personId'];

  $sql2 = "SELECT * FROM `user-likes` WHERE userId=$userId AND articleId=$articleId";
  $result2 = $conn->query($sql2);
  $userlikes = $result2->fetch_assoc();

  if ($userlikes) {
    ?>
    <img src="images/like.png" height="20" />
    <a href="unlike_article.php?articleId=<?php echo $articleId; ?>">[unlike]</a>
    <?php
  } else {
    ?>
    <a href="like_article.php?articleId=<?php echo $articleId; ?>">[like]</a>
    <?php
  }
}

?>

<?php

$sql3 = "SELECT count(*) as likes FROM `user-likes` WHERE articleId=$articleId";
$result3 = $conn->query($sql3);
$row3 = $result3->fetch_assoc();
echo $row3['likes'];
echo " people like this";

?>

<table>
      <tr>
        <td>
          <img src="<?php echo $row['image']; ?>" height="200" />
          <h1><?php echo $row['title']; ?></h1>
          <small><?php echo $row['author']; ?></small>
          <p><?php
          $ps = explode("\r\n", $row['article']);
          $p = join('</p><p>', $ps);
          echo $p;
          ?></p>
          <a href="<?php echo $row['external_link']; ?>">Original Article</a>
        </td>
      </tr>
</table>

<?php

include('footer.php');

?>
