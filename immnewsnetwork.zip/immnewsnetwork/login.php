<!DOCTYPE html>
<html>
<head>
</head>
<body>
  <form action="process-login.php" method="POST">
   username: <input type="text" name="username" />
   password: <input type="text" name="password" />
   <br>
   <input type="submit" /><br>
   <br>
   <br>
   <a href="register.php">Register here</a>
  </form>
</body>
</html>
